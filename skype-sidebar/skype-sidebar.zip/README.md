# Skype as a Sidebar for Firefox

## What it does

Allows it to run [Skype](https://web.skype.com) as a sidebar on your browser.
<!--
## Screenshot

 ![screenshot](screenshot.png) -->
