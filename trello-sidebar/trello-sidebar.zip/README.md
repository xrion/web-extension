# Whatsapp Messenger as a Sidebar

## What it does

Allows it to run [Whatsapp Messenger](https://web.whatsapp.com) as a sidebar on your browser.
<!--
## Screenshot

 ![screenshot](screenshot.png) -->
